package com.example.Servizi.Email2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiziEmail02Application {

	public static void main(String[] args) {
		SpringApplication.run(ServiziEmail02Application.class, args);
	}

}
